#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define SIZE 11
#define NB_MSG 10

char tabl[NB_MSG][SIZE] = {
    "TP1 18/09", 
    "bonjour..", 
    "Hello! ;)", 
    "ça va ?? ", 
    "crypto <3", 
    "4A -- STI", 
    "I <3 info", 
    "message  ", 
    "secret ??", 
    "Vigenère "
};

void Xor(char * x, char * y, char * z){
    //TODO
}

void encrypt(char * key, char * plain, char * cipher){
    //TODO
}

void decrypt(char * key, char * plain, char * cipher){
    //TODO
}

void generate_challenge(char * cipher_r, char * cipher_s){
    //TODO
}

void attack(char * cipher_r, char * cipher_s){
    //TODO
}


int main(int argc, char *argv[]) {
    srand( time( NULL ) );
    
    char key[SIZE]; // Key generator
    int i;
    for (i = 0; i < SIZE - 1; i ++){
        int c = 33 +(rand() % 92); // 33 -> 125 caractères affichables
        key[i] = c;
    }
    key[i] = '\0';
    
    char plain[SIZE]; // Plaintext
    printf("Message à chiffrer :\n");
    scanf("%s", plain);
    
    char plainRes[SIZE];
    char cipher[SIZE];
    plainRes[0] = '\0';
    cipher[0] = '\0';
    
    encrypt(key, plain, cipher); 
    decrypt(key, plainRes, cipher);
    
    printf("Clé : %s \nMessage : %s \nChiffré : %s \nDéchiffré : %s \n", key, plain, cipher, plainRes);
    
    char cipher_r[SIZE];
    char cipher_s[SIZE];
    
    generate_challenge(cipher_r,cipher_s);
    attack(cipher_r,cipher_s);
    
    return 0;
}
